create or replace TRIGGER simul_activite
BEFORE INSERT ON appartenance_activite_agenda FOR EACH ROW
DECLARE 
    supernon int;
    dureenum int;
    datetest VARCHAR2(100);
    
    cursor date_complete is
        Select to_char(a.date_debut, 'DD-MM-YYYY HH24:MI')
        from appartenance_activite_agenda aaa, activite a
        where aaa.id_agenda = :NEW.id_agenda
        AND aaa.id_activite = a.id_activite
        AND aaa.id_activite != :NEW.id_activite;
        
date_r_complete VARCHAR2(100);

cursor date_duree is
        Select a.duree
        from appartenance_activite_agenda aaa, activite a
        where aaa.id_agenda = :NEW.id_agenda
        AND aaa.id_activite = a.id_activite
        AND aaa.id_activite != :NEW.id_activite;
        
date_r_duree activite.duree%TYPE;
        
BEGIN
    SELECT a.superposition INTO supernon
    FROM agenda a
    WHERE A.ID_AGENDA = :NEW.ID_AGENDA;
    
     SELECT to_char(ac.date_debut, 'DD-MM-YYYY HH24:MI') INTO datetest
        FROM activite ac
        WHERE ac.id_activite = :NEW.id_activite;
        
    SELECT ac.duree INTO dureenum
        FROM activite ac
        WHERE ac.id_activite = :NEW.id_activite;

    IF supernon = 0 THEN
        OPEN date_complete;
        OPEN date_duree;
        LOOP
            FETCH date_complete INTO date_r_complete;
            EXIT WHEN date_complete%NOTFOUND; 
            
            FETCH date_duree INTO date_r_duree;
            EXIT WHEN date_duree%NOTFOUND;
    
            
            IF ((to_date(datetest, 'DD-MM-YYYY HH24:MI') BETWEEN to_date(date_r_complete, 'DD-MM-YYYY HH24:MI') 
                                                        AND to_date(date_r_complete, 
                                                                    'DD-MM-YYYY HH24:MI') + (date_r_duree/24/60))
                OR (to_date(datetest, 'DD-MM-YYYY HH24:MI') + (dureenum/24/60) BETWEEN to_date(date_r_complete, 'DD-MM-YYYY HH24:MI') 
                                                        AND to_date(date_r_complete, 
                                                                    'DD-MM-YYYY HH24:MI') + (date_r_duree/24/60)))
            THEN
                raise_application_error(-20000, 'Attention: Vous ne pouvez pas faire une superposition avec cet horaire!');
            END IF;
            
        END LOOP;
        CLOSE date_duree;
        CLOSE date_complete;
    ELSE 
        dbms_output.put_line('Superposition possible');
    END IF;
END;

        
