create or replace FUNCTION SEARCH_ACTIVITY RETURN VARCHAR2 IS
    output VARCHAR2(1300);
BEGIN        
    SELECT a.id_activite || ',' || a.id_categorie || ',"' || a.titre || '","' || a.descriptif || '",' || a.id_categorie
         || ',"' || a.lieu || '",' || a.date_debut || ',' || a.date_fin || ',' || a.recurrence || ',' || a.duree
    INTO output
    FROM activite a
    WHERE id_activite = 1;

    
    RETURN(output);
END SEARCH_ACTIVITY;
/

SELECT '"ID_ACTIVITE","ID_UTILISATEUR","TITRE","DESCRIPTIF","ID_CATEGORIE","LIEU","DATE_DEBUT","DATE_FIN","RECURRENCE","DUREE"',
        search_activity FROM dual;
        
        
CREATE OR REPLACE PROCEDURE FUSION(nmbr in INT) IS
    i INT;
    zu INT := nmbr;
    dedans INT := 1;
    nume appartenance_activite_agenda.id_agenda%TYPE;
    cursor etape_cur is
                SELECT aaa.id_activite FROM  appartenance_activite_agenda aaa
                WHERE aaa.id_agenda = zu;
    etape_r appartenance_activite_agenda.id_activite%TYPE; 
    
    cursor cur is
                SELECT id_activite
                from appartenance_activite_agenda
                WHERE id_agenda = (Select max(id_agenda) from agenda);
    cur_r appartenance_activite_agenda.id_activite%TYPE; 

BEGIN
    SELECT a.id_agenda INTO i
    FROM agenda a
    WHERE a.titre = 'Fusion27';

    SELECT max(a.id_agenda) INTO nume
    FROM agenda a;
        

    OPEN etape_cur;
        LOOP
            FETCH etape_cur INTO etape_r;
            EXIT WHEN etape_cur%NOTFOUND;  
            
            OPEN cur;
                LOOP
                    FETCH cur INTO cur_r;                
                    EXIT WHEN cur%NOTFOUND;
                
                    IF etape_r = cur_r THEN 
                        dedans := 0;
                        exit;    
                    ELSE 
                        CONTINUE;
                    END IF;
                END LOOP;
            
            CLOSE cur;
            
            IF dedans = 1 then
                INSERT INTO appartenance_activite_agenda VALUES (nume, etape_r);
            END IF;
        END LOOP;
    CLOSE etape_cur;
    
    IF zu > 1 THEN
        zu := zu - 1;
        FUSION(zu);
    END IF;
    
    EXCEPTION WHEN NO_DATA_FOUND then  
        INSERT INTO AGENDA (id_utilisateur, titre, descriptif, superposition, note) 
            VALUES (1, 'Fusion27', 'Fusionnage de plusieurs agendas', 0, null);  
        FUSION(zu);
END;
/

execute FUSION(4);

CREATE OR REPLACE PROCEDURE DIFFERER IS

cursor cur is
    SELECT id_activite, id_utilisateur, titre, id_categorie, lieu, recurrence, duree
    FROM activite a
    WHERE a.id_categorie = 13
        AND a.date_debut between '01/12/19' AND '02/12/19';
    
z_activite activite.id_activite%TYPE;
z_utilisateur activite.id_utilisateur%TYPE;
z_titre activite.titre%TYPE;
z_categorie activite.id_categorie%TYPE;
z_lieu activite.lieu%TYPE;
z_recurrence activite.recurrence%TYPE;
z_duree activite.duree%TYPE;


cursor ruc is
    Select aaa.id_agenda
    from appartenance_activite_agenda aaa, activite a
    where aaa.id_activite = a.id_activite
        AND a.id_categorie = 13
        and a.date_debut between '01/12/19' AND '02/12/19';
        
z_agenda appartenance_activite_agenda.id_agenda%TYPE;

nume INT;
    
BEGIN
    OPEN cur;
    OPEN ruc;
        LOOP
            FETCH cur INTO z_activite, z_utilisateur, z_titre, z_categorie, z_lieu, z_recurrence, z_duree;
            EXIT WHEN cur%NOTFOUND; 
            INSERT INTO activite (id_utilisateur, titre, descriptif, id_categorie, lieu, date_debut, recurrence, duree) 
                    VALUES (z_utilisateur, z_titre, 'Acheter BD sorties au cours de la semaine', z_categorie, z_lieu, '06/12/19', z_recurrence, z_duree);
            SELECT max(id_activite) into nume from activite;
            FETCH ruc INTO z_agenda;
            
            INSERT INTO appartenance_activite_agenda VALUES (z_agenda, nume);
        END LOOP;
    CLOSE ruc;
    CLOSE cur;
    
END;
/

EXECUTE DIFFERER;