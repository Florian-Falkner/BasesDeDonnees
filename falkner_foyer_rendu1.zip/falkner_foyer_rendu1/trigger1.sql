create or replace TRIGGER activite_limite
BEFORE INSERT ON appartenance_activite_agenda FOR EACH ROW
DECLARE 
    v_count int;
BEGIN
    SELECT COUNT(AAA.ID_ACTIVITE) INTO v_count
    FROM appartenance_activite_agenda AAA
    WHERE AAA.ID_AGENDA = :NEW.ID_AGENDA;

    IF v_count >= 50 then
        raise_application_error(-20000, 'Attention: Vous ne pouvez pas dépasser 50 activités par agenda!');
    END IF;
END;

