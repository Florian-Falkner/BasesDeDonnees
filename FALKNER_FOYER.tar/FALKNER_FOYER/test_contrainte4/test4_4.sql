/* L'insertion fonctionne parce que la nouvelle activité commence après les autres activités donc pas de superposition (Contrainte 4) */
INSERT INTO appartenance_activite_agenda VALUES (1, 19)