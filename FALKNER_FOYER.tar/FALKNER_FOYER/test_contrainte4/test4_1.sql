/* L'insertion ne se lance pas parce que l'activité est entre les deux horaires donc superposition (Contrainte 4) */
INSERT INTO appartenance_activite_agenda VALUES (1, 16)