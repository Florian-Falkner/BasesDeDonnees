/* L'insertion ne se lance pas parce que la fin de la nouvelle activité est entre les deux horaires donc superposition (Contrainte 4) */
INSERT INTO appartenance_activite_agenda VALUES (1, 17)