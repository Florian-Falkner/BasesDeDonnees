/* L'insertion ne se lance pas parce qu'il doit attendre 5 min (Contrainte 5) */
insert into abonnement_agenda (ID_AGENDA, ID_UTILISATEUR, PRIORITE, NOTE) VALUES (4, 1, 0, 1)