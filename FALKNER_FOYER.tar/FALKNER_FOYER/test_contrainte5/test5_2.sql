/* insere une ligne pour tester la contrainte 5 */
insert into abonnement_agenda (ID_AGENDA, ID_UTILISATEUR, PRIORITE, NOTE) VALUES (4, 1, 0, 1)