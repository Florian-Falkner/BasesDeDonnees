### README PROJET BDD2 ###



### PRECISIONS ###

#CI-DESSOUS VOUS EST PROPOSÉ UN ORDRE D'EXECUTION DE NOS FICHIERS SQL. IL EST NECESSAIRE DE LE SUIVRE POUR S'ASSURER DU BON FONCTIONNEMENT DE LA BASE DE DONNEES
 1. supression_tables.sql
 2. creation_tables.sql
 3. insertion_donnees.sql
 4. requetes.sql
 5. contraintes_integrite.sql
 6. Procedures.sql

#LA BASE DE DONNEES RESPECTE L'ENTIERTE DES CONTRAINTES IMPOSEES PAR LE SUJET
#TOUTES LES REQUETES, PROCEDURES ET CONTRAINTES ONT ETE IMPLEMENTEES (VOIR EXCEPTION CONTRAINTE 3 CI-DESSOUS)

#LA 3EME CONTRAINTE D'INTEGRITE NE FIGURE PAS DANS NOTRE IMPLÉMENTATION: NOUS N'AVONS PAS SU L'INTERPRETER DE MANIERE COHERENTE

#PAR RAPPORT AU 1ER RENDU, NOUS AVONS MODIFIE SEULEMENT UNE COLONNE ('DATE_MODIFICATION' DANS LA TABLE UTILISATEUR).
 CECI EST NOTRE SEUL CHANGEMENT DEPUIS LE 1ER RENDU.

#TOUTES LES REQUÊTES EXIGEES PAR LE SUJET SONT CONTENUES DANS LE FICHIER 'requetes.sql'

#TOUTES LES PROCEDURES EXIGEES PAR LE SUJET SONT CONTENUES DANS LE FICHIER 'procedures.sql'



### CONTRAINTES D'INTEGRITE ###

#UNE BATTERIE DE TESTS POUR VERIFIER NOS CONTRAINTES D'INTEGRITE VOUS EST FOURNIE.
 DANS CETTE ARCHIVE, VOUS TROUVEREZ 3 SOUS-DOSSIERS: TEST_CONTRAINTE2, TEST_CONTRAINTE4, TEST_CONTRAINTE5 CONTENANT LES DIFFÉRENTS TESTS .SQL
 CI-DESSOUS VOUS TROUVEREZ LES RESULTATS ATTENDUS AUX TESTS PRÉPARÉS POUR LES CONTRAINTES 2,4,5

--- TEST CONTRAINTE 2 ---
DELETE FROM AGENDA WHERE ID_AGENDA = 6;
DELETE FROM ACTIVITE WHERE ID_ACTIVITE = 4;

-> l'agenda ainsi que l'activite se retrouvent dans la table d'archivage


--- TEST CONTRAINTE 4 ---
INSERT INTO appartenance_activite_agenda VALUES (1, 16)
-> L'insertion ne se lance pas parce que l'activité est entre les deux horaires donc superposition

INSERT INTO appartenance_activite_agenda VALUES (1, 17)
-> L'insertion ne se lance pas parce que la fin de la nouvelle activité est entre les deux horaires donc superposition

INSERT INTO appartenance_activite_agenda VALUES (1, 18)
-> L'insertion fonctionne parce que la fin de la nouvelle activité se fini avant les autres activités donc pas de superposition

INSERT INTO appartenance_activite_agenda VALUES (1, 19)
-> L'insertion fonctionne parce que la nouvelle activité commence après les autres activités donc pas de superposition


--- TEST CONTRAINTE 5 --- 
INSERT INTO ABONNEMENT_AGENDA (ID_AGENDA, ID_UTILISATEUR, PRIORITE, NOTE) VALUES (3, 2, 1, 3)
-> insere une ligne car utilisateur ancien

INSERT INTO ABONNEMENT_AGENDA (ID_AGENDA, ID_UTILISATEUR, PRIORITE, NOTE) VALUES (4, 1, 0, 1)
-> insere une ligne car utilisateur recent mais n'a pas encore évalué d'agenda/activite

INSERT INTO ABONNEMENT_AGENDA (ID_AGENDA, ID_UTILISATEUR, PRIORITE, NOTE) VALUES (4, 1, 0, 1)
-> ne fonctionne pas, l'utilisateur recent doit attendre 5 min


